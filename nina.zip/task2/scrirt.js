document.getElementById('reset').onclick = function() {
    var el = document.getElementById('header');
    el.style.display === 'none' ? el.style.display = 'initial' : el.style.display = 'none';
  }